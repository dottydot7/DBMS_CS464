/* Q1: List the name of all the museums that belong to TSI. */
select CName from component
where CType = 'Museum'
;

/* Q2: List one museum with all the information about it that you have in
your database. */
select * from component
where CName = 'Freer Gallery of Art'
;

/* Q3: How many objects are there in total in TSI? (owned by TSI) */
select count (*) from object
;

/* Q4:  List of events within a time frame in 2019 with the data of the host or
location where they take place. */
select EVName "event name", EVVenueComponent as Component, EVVenueRoom as Room,
EVstreet ||' '||EVCity||' '|| EVState as Location
from EVENT
where EVSTARTYEAR = 2019
;

/* Q5: Artists with more than two works of art owned by TSI and list the
Name of the Artist with their number of works. */
select creator Artist, count(recordid) "Number of Works"
from object
where ocategory = 'W'
group by creator
having count(recordid) > 2
order by count(recordid) desc
;