CREATE TABLE MEMBERSHIP ( 
    MLevel		VARCHAR2(100)    NOT NULL,
    FeeMin		INTEGER   		 NOT NULL,
    FeeMax		INTEGER   		 NOT NULL,
    
	CHECK (FeeMax >= FeeMin and FeeMin >= 0),
    
    CONSTRAINT MEMSHIPPK PRIMARY KEY (MLevel)
);

CREATE TABLE BENEFIT ( 
    BKey			INTEGER				NOT NULL,
    BLevel			VARCHAR2(100)		NOT NULL,
    BDescription	VARCHAR2(250)		NOT NULL,

    CONSTRAINT BENPK PRIMARY KEY (BKey, BLevel),
    
    CONSTRAINT BENFK FOREIGN KEY (BLevel) REFERENCES MEMBERSHIP(MLevel)
      ON DELETE CASCADE
);

CREATE TABLE MEMBER ( 
    Email    		VARCHAR2(250)    NOT NULL,
    FirstName   	VARCHAR2(100)    NOT NULL,
    LastName    	VARCHAR2(100)    NOT NULL,
    Street    		VARCHAR2(100)    NOT NULL,
    City    		VARCHAR2(100)    NOT NULL,
    State    		VARCHAR2(100)    NOT NULL,
    ZIP    		 	VARCHAR2(50)     NOT NULL,
    BillingName  	VARCHAR2(200)	 NOT NULL,
    CardNum    		VARCHAR2(50)	 NOT NULL,
    CardExp    		VARCHAR2(10)	 NOT NULL,
    CVV    			VARCHAR2(10)	 NOT NULL,
    MLevel    		VARCHAR2(100)    NOT NULL,
  	Fee    			INTEGER    		 NOT NULL,
  	JoinMonth    	INTEGER    		 NOT NULL,
  	JoinDay    		INTEGER    		 NOT NULL,
  	JoinYear   		INTEGER    		 NOT NULL,

    CONSTRAINT MEMBERPK PRIMARY KEY (Email),

    CONSTRAINT MEMBERFK FOREIGN KEY (MLevel) REFERENCES MEMBERSHIP(MLevel)
      ON DELETE SET NULL
);

CREATE TABLE EDUCATION_CENTER ( 
    EDProgram			VARCHAR2(100)		NOT NULL,
    EDDescription		VARCHAR2(2000),
    EDURL				VARCHAR2(2050)		NOT NULL,
    EDStreet			VARCHAR2(100),
    EDCity				VARCHAR2(100),
    EDState				VARCHAR2(100),
    EDRestrictions		VARCHAR2(500),
    EDOpenDay			VARCHAR2(100),
    EDOpenTime			VARCHAR2(50),
    EDCloseTime			VARCHAR2(50),
    EDAreaCode			VARCHAR2(5),
    EDPhoneNum			VARCHAR2(20),
    
    CHECK (EDCloseTime >= EDOpenTime),

    CONSTRAINT EDUCPK PRIMARY KEY (EDProgram)
);

CREATE TABLE COMPONENT (
	CName				VARCHAR2(100)		NOT NULL,
    CType				VARCHAR2(20)		NOT NULL,
    CRestrictions		VARCHAR2(500)		NOT NULL,
    CURL				VARCHAR2(2050)		NOT NULL,
    CDescription		VARCHAR2(2000),
    CHighlights			VARCHAR2(1000)		NOT NULL,
    CStreet				VARCHAR2(100)		NOT NULL,
    CCity				VARCHAR2(100)		NOT NULL,
    CState				VARCHAR2(100)		NOT NULL,
    CCost				VARCHAR2(100)		NOT NULL,
    COpenDay			VARCHAR2(100)		NOT NULL,
    COpenTime			VARCHAR2(50)		NOT NULL,
    CCloseTime			VARCHAR2(50)		NOT NULL,
    CDining				VARCHAR2(400),
    CParking			VARCHAR2(400)		NOT NULL,
    CTransport			VARCHAR2(400),
    CPassDay			VARCHAR2(3)			NOT NULL,
    CPassEntryTime		VARCHAR2(50)		NOT NULL,
    CPassExitTime		VARCHAR2(50)		NOT NULL,
    CAreaCode			VARCHAR2(5),
    CPhoneNum			VARCHAR2(20),
    
	CHECK (CCloseTime >= COpenTime),
    CHECK (CPassExitTime >= CPassEntryTime),
    CHECK (CType in ('Museum','Garden', 'Gallery', 'Zoo')),

    CONSTRAINT COMPPK PRIMARY KEY (CName)
);


CREATE TABLE CULTURAL_CENTER (
    CCName				VARCHAR2(100)		NOT NULL,
    CCURL				VARCHAR2(2050)		NOT NULL,
    CCDescription		VARCHAR2(2000),
    CCStreet			VARCHAR2(100),
    CCCity				VARCHAR2(100),
    CCState				VARCHAR2(100),
    CCRestrictions		VARCHAR2(500)		NOT NULL,
    CCOpenDay			VARCHAR2(100),
    CCOpenTime			VARCHAR2(50),
    CCCloseTime			VARCHAR2(50),
    CCAreaCode			VARCHAR2(5)			NOT NULL,
    CCPhoneNum			VARCHAR2(20)		NOT NULL,
    
    CHECK (CCCloseTime >= CCOpenTime),
  
    CONSTRAINT CULTPK PRIMARY KEY (CCName)
);

CREATE TABLE EVENT (
    EVName				VARCHAR2(100)		NOT NULL,
    EVAccessURL			VARCHAR2(2050),
    EVAccessibility		VARCHAR2(2000),
    EVCategory			VARCHAR2(200)		NOT NULL,
    EVStartMonth		INTEGER				NOT NULL,
    EVStartDay			INTEGER				NOT NULL,
    EVStartYear			INTEGER				NOT NULL,
    EVEndMonth			INTEGER				NOT NULL,
    EVEndDay			INTEGER				NOT NULL,
    EVEndYear			INTEGER				NOT NULL,
    EVCost				VARCHAR2(100)		NOT NULL,
    EVDescription		VARCHAR2(2000),
    EVStreet			VARCHAR2(100)		NOT NULL,
    EVCity				VARCHAR2(100)		NOT NULL,
    EVState				VARCHAR2(100)		NOT NULL,
    EVURL				VARCHAR2(2050)		NOT NULL,
    EVFlag				VARCHAR2(20),
    EVStatus			VARCHAR2(10)		NOT NULL,
    EVTicketsRegister	VARCHAR2(2500)		NOT NULL,
    EVStartTime			VARCHAR2(50)		NOT NULL,
    EVEndTime			VARCHAR2(50)		NOT NULL,
    EVVenueComponent	VARCHAR2(100),
    EVVenueRoom			VARCHAR2(100),
    EVCulturalCenter	VARCHAR2(100),
    
    CHECK (EVEndTime >= EVStartTime),
    CHECK (EVEndYear >= EVStartYear),
    CHECK (EVEndDay >= EVStartDay),
    CHECK (EVEndMonth >= EVStartMonth),
    
    CONSTRAINT EVENTPK PRIMARY KEY (EVName, EVStartYear),

    CONSTRAINT EVENTCOMFK FOREIGN KEY (EVVenueComponent) REFERENCES COMPONENT(CName)
      ON DELETE SET NULL,
    
    CONSTRAINT EVENTCULFK FOREIGN KEY (EVCulturalCenter) REFERENCES CULTURAL_CENTER(CCName)
      ON DELETE SET NULL
);

CREATE TABLE EXHIBITION (
    EXName				VARCHAR2(100)		NOT NULL,
    EXStartMonth		INTEGER				NOT NULL,
    EXStartDay			INTEGER				NOT NULL,
    EXStartYear			INTEGER				NOT NULL,
    EXEndMonth			INTEGER,
    EXEndDay			INTEGER,
    EXEndYear			INTEGER,
    EXStatus			VARCHAR2(10)		NOT NULL,
    EXCategory			VARCHAR2(200)		NOT NULL,
    EXOpenDay			VARCHAR2(100),
    EXOpenTime			VARCHAR2(50),
    EXCloseTime			VARCHAR2(50),
    EXDescription		VARCHAR2(2000),
    EXStreet			VARCHAR2(100)		NOT NULL,
    EXCity				VARCHAR2(100)		NOT NULL,
    EXState				VARCHAR2(100)		NOT NULL,
    EXURL				VARCHAR2(2050)		NOT NULL,
    EXCulturalCenter	VARCHAR2(100),
    EXVenueComponent	VARCHAR2(100)		NOT NULL,
    
    CHECK (EXCloseTime >= EXOpenTime),
    CHECK (EXEndYear >= EXStartYear),
    CHECK (EXEndDay >= EXStartDay),
    CHECK (EXEndMonth >= EXStartMonth),

    CONSTRAINT EXPK PRIMARY KEY (EXName, EXStartYear),

    CONSTRAINT EXCOMFK FOREIGN KEY (EXVenueComponent) REFERENCES COMPONENT(CName)
      ON DELETE CASCADE,
    
    CONSTRAINT EXCULFK FOREIGN KEY (EXCulturalCenter) REFERENCES CULTURAL_CENTER(CCName)
      ON DELETE SET NULL
);

CREATE TABLE RESEARCH_CENTER (
    RName			VARCHAR2(100)		NOT NULL,
    RURL			VARCHAR2(2050)		NOT NULL,
    RDescription	VARCHAR2(2000),
    RStreet			VARCHAR2(100)		NOT NULL,
    RCity			VARCHAR2(100)		NOT NULL,
    RState			VARCHAR2(100)		NOT NULL,
    RRestrictions	VARCHAR2(500)		NOT NULL,
    ROpenDay		VARCHAR2(100),
    ROpenTime		VARCHAR2(50),
    RCloseTime		VARCHAR2(50),
    RAreaCode		VARCHAR2(5)			NOT NULL,
    RPhoneNum		VARCHAR2(20)		NOT NULL,
    
    CHECK (RCloseTime >= ROpenTime),
  
    CONSTRAINT RESEARCHPK PRIMARY KEY (RName)
);

CREATE TABLE PUBLICATION (
    PTitle			VARCHAR2(400)	NOT NULL,
    PMonth			INTEGER			NOT NULL,
    PDay			INTEGER			NOT NULL,
    PYear			INTEGER			NOT NULL,
    PDepartment		VARCHAR2(100)	NOT NULL,
    PAuthorFirst	VARCHAR2(100)	NOT NULL,
    PAuthorLast		VARCHAR2(100)	NOT NULL,
    RName			VARCHAR2(100)	NOT NULL,
    
    CONSTRAINT PUBPK PRIMARY KEY (PTitle,PMonth,PDay,PYear),

    CONSTRAINT PUBFK FOREIGN KEY (RName) REFERENCES RESEARCH_CENTER(RName)
      ON DELETE CASCADE
);

CREATE TABLE OBJECT (
    RecordID				VARCHAR2(20)		NOT NULL,
    OCategory				VARCHAR2(1)			NOT NULL,
    OName					VARCHAR2(100)		NOT NULL,
    OMonth					INTEGER,
    ODay					INTEGER,
    OYear					INTEGER,
    Creator					VARCHAR2(100),
    Subject					VARCHAR2(100),
    CitationName			VARCHAR2(100),
    CitationCollection		VARCHAR2(100),
    CitationCenter			VARCHAR2(100),
    Medium					VARCHAR2(100)		NOT NULL,
    Width					VARCHAR2(100)		NOT NULL,
    Height					VARCHAR2(100)		NOT NULL,
    Length					VARCHAR2(100)		NOT NULL,
    ODescription			VARCHAR2(2000),
    Classification			VARCHAR2(100),
    OType					VARCHAR2(100)		NOT NULL,
    OTopic					VARCHAR2(100)		NOT NULL,
    CreditLine				VARCHAR2(4000),
    Usage					VARCHAR2(100)		NOT NULL,
    Provenance				VARCHAR2(100),
    ExhibitionHistory		VARCHAR2(4000),
    Movement				VARCHAR2(100),
    
    CHECK (OCategory in ('A','W')),
    
    CONSTRAINT OBJECTPK PRIMARY KEY (RecordID, OCategory),

    CONSTRAINT OBJECTFK FOREIGN KEY (CitationCenter) REFERENCES RESEARCH_CENTER(RName)
      ON DELETE SET NULL   
);

CREATE TABLE ARTIFACT (
    RecordID			VARCHAR2(20)		NOT NULL,
    OCategory			VARCHAR2(1)			NOT NULL,
    CollectionTitle		VARCHAR2(100),
    OriginCountry		VARCHAR2(100),
    Geography			VARCHAR2(100),
    LabelText			VARCHAR2(4000),
    Manufacturer		VARCHAR2(100),
    
    CONSTRAINT ARTIFACTPK PRIMARY KEY (RecordID),

    CONSTRAINT ARTIFACTFK FOREIGN KEY (RecordID, OCategory) REFERENCES OBJECT(RecordID, OCategory)
      ON DELETE CASCADE 
);

CREATE TABLE WORK_OF_ART(
    RecordID				VARCHAR2(20)		NOT NULL,
    OCategory				VARCHAR2(1)			NOT NULL,
    Caption					VARCHAR2(4000),
    PlaceDepicted			VARCHAR2(100),
    School					VARCHAR2(100),
    Series					VARCHAR2(100),
    PublishedReferences		VARCHAR2(4000),
    
    CONSTRAINT WOAPK PRIMARY KEY (RecordID),

    CONSTRAINT WOAFK FOREIGN KEY (RecordID, OCategory) REFERENCES OBJECT(RecordID, OCategory)
      ON DELETE CASCADE 
);

CREATE TABLE LIFE (
    Genus			VARCHAR2(100)		NOT NULL,
    Species			VARCHAR2(100)		NOT NULL,
    LCategory		VARCHAR2(1)			NOT NULL,
    Class			VARCHAR2(100)		NOT NULL,
    Family			VARCHAR2(100)		NOT NULL,
    LOrder			VARCHAR2(100)		NOT NULL,
    LName			VARCHAR2(100)		NOT NULL,
    
    CHECK (LCategory in ('FL','FA')),
    
    CONSTRAINT LIFEPK PRIMARY KEY (Genus, Species, LCategory)
);

CREATE TABLE FLORA (
    Genus			VARCHAR2(100)		NOT NULL,
    Species			VARCHAR2(100)		NOT NULL,
    LCategory		VARCHAR2(1)			NOT NULL,
    CommonName		VARCHAR2(100)		NOT NULL,
    FlowerColor		VARCHAR2(100)		NOT NULL,
    FLGroup			VARCHAR2(100)		NOT NULL,
    LifeForm		VARCHAR2(100)		NOT NULL,
    Parentage		VARCHAR2(100),
    FLProvenance	VARCHAR2(100)		NOT NULL,
    FLRange			VARCHAR2(100)		NOT NULL,
    Subclass		VARCHAR2(100)		NOT NULL,
    SuperOrder		VARCHAR2(100),
    FLTopic			VARCHAR2(100)		NOT NULL,
    FLUsage			VARCHAR2(100)		NOT NULL,
    
    CONSTRAINT FLORAPK PRIMARY KEY (Genus, Species),

    CONSTRAINT FLORAFK FOREIGN KEY (Genus, Species, LCategory) REFERENCES LIFE(Genus, Species, LCategory)
      ON DELETE CASCADE 
);

CREATE TABLE FAUNA (
    Genus			VARCHAR2(100)		NOT NULL,
    Species			VARCHAR2(100)		NOT NULL,
    LCategory		VARCHAR2(1)			NOT NULL,
    Communication	VARCHAR2(2000),
    FDescription	VARCHAR2(2000)		NOT NULL,
    Food			VARCHAR2(2000)		NOT NULL,
    Habitat			VARCHAR2(2000)		NOT NULL,
    Reproduction	VARCHAR2(2000)		NOT NULL,
    FSize			VARCHAR2(100) 		NOT NULL,
    FWeight			VARCHAR2(100)		NOT NULL,
    Sleep			VARCHAR2(2000),
    Social			VARCHAR2(2000)		NOT NULL,

    CONSTRAINT FAUNAPK PRIMARY KEY (Genus, Species),

    CONSTRAINT FAUNAFK FOREIGN KEY (Genus, Species, LCategory) REFERENCES LIFE(Genus, Species, LCategory)
      ON DELETE CASCADE 
);

CREATE TABLE ODISPLAY (
    RecordID			VARCHAR2(20)	NOT NULL,
    OCategory			VARCHAR2(1)		NOT NULL,
    OnViewComponent		VARCHAR2(100)	NOT NULL,
    OnViewFloor			VARCHAR2(100),
    OnViewRoom			VARCHAR2(100),
    OnViewConcourse		VARCHAR2(100),
    
    CONSTRAINT ODISPPK PRIMARY KEY (RecordID, OCategory, OnViewComponent),

    CONSTRAINT ODISPOBJFK FOREIGN KEY (RecordID, OCategory) REFERENCES OBJECT(RecordID, OCategory)
      ON DELETE CASCADE, 
        
    CONSTRAINT ODISPCOMPFK FOREIGN KEY (OnViewComponent) REFERENCES COMPONENT(CName)
      ON DELETE CASCADE 
    
);

CREATE TABLE LDISPLAY (
    Genus				VARCHAR2(100)		NOT NULL,
    Species				VARCHAR2(100)		NOT NULL,
    LCategory			VARCHAR2(1)			NOT NULL,
    OnViewComponent		VARCHAR2(100)		NOT NULL,
    
    
    CONSTRAINT LDISPPK PRIMARY KEY (Genus, Species, LCategory, OnViewComponent),

    CONSTRAINT LDISPLIFEFK FOREIGN KEY (Genus, Species, LCategory) REFERENCES LIFE(Genus, Species, LCategory)
      ON DELETE CASCADE, 
        
    CONSTRAINT LDISPCOMPFK FOREIGN KEY (OnViewComponent) REFERENCES COMPONENT(CName)
      ON DELETE CASCADE    
);